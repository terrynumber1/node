prefix = 'Relaying: ';

module.exports = function (message) {
	console.log(prefix + message);
};