var announce = require('./announce');

announce('Node Essential Training');