var relay = require('./relay');

prefix = "Attention: ";

relay('Ticket counter closes at 10PM');