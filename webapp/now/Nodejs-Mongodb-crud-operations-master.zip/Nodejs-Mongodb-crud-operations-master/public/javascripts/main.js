/**
 * Created by jlone on 8/3/2014.
 */
/*$(function() {
    $('#s').on('click', function() {
        $('.needs-validation').each(function() { console.log($('this'));
            if($(this).val() === '') {
                $(this).css('border','5px solid red');
                $(this).focus();
                return false;
            }
            else {
                $(this).css('border','3px solid #000');
            }
        });
        $('form').submit();
    });
    });*/
